import React, { useState, useEffect } from 'react';
import LexiconManager from './components/LexiconManager';
import WordGenerator from './components/WordGenerator';
import VyianjiCanvas from './components/VyianjiCanvas';
import PhraseGenerator from './components/PhraseGenerator';
import { Download, Plus, Search, Book, PenTool, Database, Layers, MessageSquare, Library, Trash2 } from 'lucide-react';
import { exportToExcel } from './utils/ExcelExporter';

function App() {
    const [activeTab, setActiveTab] = useState('lexicon');
    const [roots, setRoots] = useState(() => {
        const saved = localStorage.getItem('vyio_roots');
        return saved ? JSON.parse(saved) : [
            { id: 1, vyio: 'kai', spanish: 'poder', category: 'esencia' },
            { id: 2, vyio: 'shen', spanish: 'emoción', category: 'emoción' },
            { id: 3, vyio: 'ryo', spanish: 'naturaleza/batalla', category: 'guerra' },
        ];
    });

    const [prefixes, setPrefixes] = useState(() => {
        const saved = localStorage.getItem('vyio_prefixes');
        return saved ? JSON.parse(saved) : [
            { id: 1, vyio: 'vy', spanish: 'perfección' },
            { id: 2, vyio: 'no', spanish: 'vacío' },
            { id: 3, vyio: 'kai', spanish: 'absorción' },
        ];
    });

    const [suffixes, setSuffixes] = useState(() => {
        const saved = localStorage.getItem('vyio_suffixes');
        return saved ? JSON.parse(saved) : [
            { id: 1, vyio: 'ka', spanish: 'colectivo' },
            { id: 2, vyio: 'shi', spanish: 'futuro' },
            { id: 3, vyio: 'ta', spanish: 'pasado' },
            { id: 4, vyio: 'en', spanish: 'estado' },
            { id: 5, vyio: 'yo', spanish: 'intensidad' },
            { id: 6, vyio: 'dor', spanish: 'conflicto' },
        ];
    });

    const [words, setWords] = useState(() => {
        const saved = localStorage.getItem('vyio_words');
        return saved ? JSON.parse(saved) : [];
    });

    const [phrases, setPhrases] = useState(() => {
        const saved = localStorage.getItem('vyio_phrases');
        return saved ? JSON.parse(saved) : [];
    });

    useEffect(() => {
        localStorage.setItem('vyio_roots', JSON.stringify(roots));
    }, [roots]);

    useEffect(() => {
        localStorage.setItem('vyio_prefixes', JSON.stringify(prefixes));
    }, [prefixes]);

    useEffect(() => {
        localStorage.setItem('vyio_suffixes', JSON.stringify(suffixes));
    }, [suffixes]);

    useEffect(() => {
        localStorage.setItem('vyio_words', JSON.stringify(words));
    }, [words]);

    useEffect(() => {
        localStorage.setItem('vyio_phrases', JSON.stringify(phrases));
    }, [phrases]);

    const removeWord = (id) => {
        if (window.confirm('¿Deseas eliminar esta palabra de la biblioteca?')) {
            setWords(words.filter(w => w.id !== id));
        }
    };

    const removePhrase = (id) => {
        if (window.confirm('¿Deseas eliminar esta frase del registro?')) {
            setPhrases(phrases.filter(p => p.id !== id));
        }
    };

    return (
        <div className="min-h-screen p-4 md:p-12 max-w-7xl mx-auto">
            <header className="mb-16 text-center animate-fade-in">
                <h1 className="text-6xl md:text-8xl font-black mb-4 tracking-tighter gradient-text text-glow pb-2">
                    VYIANÓRA
                </h1>
                <p className="text-xl font-light text-text-muted tracking-[0.4em] uppercase opacity-80">Generador de Conceptos</p>
            </header>

            <nav className="flex flex-wrap gap-3 mb-12 justify-center animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <button
                    onClick={() => setActiveTab('lexicon')}
                    className={`nav-tab flex items-center gap-2 ${activeTab === 'lexicon' ? 'active' : ''}`}
                >
                    <Book size={18} /> Léxico
                </button>
                <button
                    onClick={() => setActiveTab('words')}
                    className={`nav-tab flex items-center gap-2 ${activeTab === 'words' ? 'active' : ''}`}
                >
                    <Plus size={18} /> Generador
                </button>
                <button
                    onClick={() => setActiveTab('phrases')}
                    className={`nav-tab flex items-center gap-2 ${activeTab === 'phrases' ? 'active' : ''}`}
                >
                    <MessageSquare size={18} /> Frases
                </button>
                <button
                    onClick={() => setActiveTab('library')}
                    className={`nav-tab flex items-center gap-2 ${activeTab === 'library' ? 'active' : ''}`}
                >
                    <Library size={18} /> Biblioteca
                </button>
                <button
                    onClick={() => exportToExcel(roots, words, phrases)}
                    className="nav-tab flex items-center gap-2 border border-green-500/10 text-green-400 hover:bg-green-500/10"
                >
                    <Database size={18} /> Exportar
                </button>
            </nav>

            {/* IME-Style Preview Area - Integrated Redesign */}
            <div className="mb-12 glass-card border-none relative overflow-visible group">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-[26px] blur-2xl opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
                    <div className="flex items-center gap-6 flex-grow w-full">
                        <div className="p-4 bg-white/5 rounded-2xl shadow-inner">
                            <Search className="text-primary" size={28} />
                        </div>
                        <input
                            className="input-field bg-transparent border-none text-2xl md:text-3xl w-full focus:outline-none placeholder:text-text-muted/20 text-white font-light tracking-wide mb-0"
                            placeholder="Introduce concepto o significado..."
                            onChange={(e) => {
                                const val = e.target.value.toLowerCase();
                                const found = [...roots, ...words].find(x =>
                                    x.spanish.toLowerCase().includes(val) ||
                                    x.vyio.toLowerCase().includes(val)
                                );
                                const previewEl = document.getElementById('ime-preview');
                                if (previewEl) {
                                    if (found && val.length > 1) {
                                        previewEl.innerText = found.vyio;
                                        previewEl.classList.add('animate-fade-in');
                                    } else {
                                        previewEl.innerText = '';
                                        previewEl.classList.remove('animate-fade-in');
                                    }
                                }
                            }}
                        />
                    </div>
                    <div id="ime-preview" className="text-5xl md:text-6xl font-black text-primary tracking-[0.3em] min-w-[200px] text-center md:text-right drop-shadow-[0_0_20px_rgba(151,223,252,0.6)]"></div>
                </div>
            </div>

            <main className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
                {activeTab === 'lexicon' && (
                    <LexiconManager
                        roots={roots} setRoots={setRoots}
                        prefixes={prefixes} setPrefixes={setPrefixes}
                        suffixes={suffixes} setSuffixes={setSuffixes}
                    />
                )}
                {activeTab === 'words' && (
                    <WordGenerator
                        roots={roots}
                        prefixes={prefixes}
                        suffixes={suffixes}
                        words={words}
                        setWords={setWords}
                    />
                )}
                {activeTab === 'phrases' && (
                    <PhraseGenerator
                        roots={roots}
                        words={words}
                        phrases={phrases}
                        setPhrases={setPhrases}
                    />
                )}
                {activeTab === 'library' && (
                    <div className="space-y-16">
                        <div className="glass-card">
                            <h2 className="text-4xl font-bold mb-10 flex items-center gap-4">
                                <Library className="text-primary" size={32} /> Biblioteca de Morfemas
                            </h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                {words.length === 0 ? (
                                    <div className="col-span-full py-20 text-center text-text-muted opacity-30 italic text-xl">
                                        Empieza a generar palabras para llenar tu biblioteca...
                                    </div>
                                ) : (
                                    words.map((word, i) => (
                                        <div key={i} className="library-card group">
                                            <div className="card-glyph-container">
                                                {word.canvasData ? (
                                                    <img src={word.canvasData} alt={word.vyio} />
                                                ) : (
                                                    <div className="text-text-muted/10 font-black text-6xl">?</div>
                                                )}
                                                <div className="absolute top-4 right-4 group-hover:opacity-100 opacity-0 transition-opacity">
                                                    <button
                                                        onClick={() => removeWord(word.id)}
                                                        className="glass-action-circle"
                                                        title="Eliminar concepto"
                                                    >
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </div>

                                            <div className="space-y-1">
                                                <div className="text-2xl font-black text-primary tracking-widest uppercase truncate">{word.vyio}</div>
                                                <div className="text-xs text-text-muted font-bold uppercase tracking-tighter opacity-60 truncate">{word.spanish}</div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>

                        <div className="glass-card">
                            <h2 className="text-4xl font-bold mb-10 flex items-center gap-4">
                                <MessageSquare className="text-accent" size={32} /> Registro de Frases
                            </h2>
                            <div className="space-y-8">
                                {phrases.length === 0 ? (
                                    <div className="py-20 text-center text-text-muted opacity-30 italic text-xl">
                                        Tu historia aún no ha comenzado... construye tu primera frase.
                                    </div>
                                ) : (
                                    phrases.map((phrase, i) => (
                                        <div key={i} className="phrase-tape group">
                                            <div className="flex justify-between items-start">
                                                <div className="px-4 py-1 bg-accent/10 text-accent text-[10px] uppercase font-black tracking-[0.3em] rounded-md border border-accent/20">
                                                    Escala: {phrase.size}
                                                </div>
                                                <button
                                                    onClick={() => removePhrase(phrase.id)}
                                                    className="glass-action-circle opacity-0 group-hover:opacity-100"
                                                    title="Eliminar crónica"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>

                                            <div className="py-2">
                                                <div className="text-4xl md:text-5xl font-black text-white tracking-[0.3em] mb-4 uppercase drop-shadow-2xl">{phrase.vyio}</div>
                                                <div className="text-lg text-text-muted italic font-light">
                                                    <span className="text-accent not-italic font-black uppercase text-xs mr-3 tracking-widest">{phrase.title}:</span>
                                                    {phrase.spanish}
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </main>

            <footer className="mt-40 py-16 border-t border-white/5 text-center">
                <div className="text-text-muted/20 text-xs tracking-[0.6em] uppercase mb-4">Sistema de Dominio Lingüístico Vyianóra</div>
                <div className="text-[10px] text-text-muted/10 uppercase tracking-widest">Desarrollado con la esencia de la estructura mexicana • 2026</div>
            </footer>
        </div>
    );
}

export default App;
